Config = {}

Config.Locale = 'pl'
