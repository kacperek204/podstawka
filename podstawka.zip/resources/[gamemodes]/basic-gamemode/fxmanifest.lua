resource_type 'gametype' { name = 'Freeroam' }

client_script 'basic_client.lua'

game 'common'
fx_version 'adamant'