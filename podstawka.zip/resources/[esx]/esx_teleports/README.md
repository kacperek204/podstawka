# esx_teleports


#### Installation
```
1) Add `start esx_teleports` to your server.cfg
2) Drag it into your resources
3) Done
```
