Locales['en'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'send a tweet',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'personal action',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'RP information',
  ['do_prefix'] = 'do | %s',
  ['generic_argument_name'] = 'message',
  ['generic_argument_help'] = 'the message',
}
