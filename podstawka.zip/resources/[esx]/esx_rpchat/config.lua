Config = {}

Config.Locale = 'sv'
Config.OnlyFirstname = false
Config.EnableESXIdentity = true -- only turn this on if you are using esx_identity and want to use RP names
