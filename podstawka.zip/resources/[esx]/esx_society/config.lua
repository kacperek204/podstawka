Config = {}

Config.Locale = 'fr'
Config.EnableESXIdentity = false
Config.MaxSalary = 3500
