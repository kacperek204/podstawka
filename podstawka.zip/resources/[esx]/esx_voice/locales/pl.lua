Locales ['pl'] = {
  ['voice']   = '~y~Głos: ~s~%s',
  ['normal']  = 'normalny',
  ['shout']   = 'krzyk',
  ['whisper'] = 'szept',
}
