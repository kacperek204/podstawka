Locales ['br'] = {
  ['voice']   = '~y~Voz: ~s~%s',
  ['normal']  = 'normal',
  ['shout']   = 'gritar',
  ['whisper'] = 'sussurro',
}
