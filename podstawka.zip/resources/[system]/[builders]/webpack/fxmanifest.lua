dependency 'yarn'
server_script 'webpack_builder.js'

fx_version 'adamant'
game 'common'